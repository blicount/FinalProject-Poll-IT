module.exports = {
    MLAB_KEY:'mongodb://polldb:polldb1990@ds259410.mlab.com:59410/poll_it_service'
}
