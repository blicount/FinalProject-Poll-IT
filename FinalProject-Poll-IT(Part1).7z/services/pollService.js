var _catagories = require('../schemes/catagories'),
    consts   = require('../consts'),
    mongoose = require('mongoose'), //Import the mongoose module
    mongoDB = consts.MLAB_KEY;//Set up default mongoose connection


console.log('connect to db');
mongoose.connect(mongoDB);
mongoose.Promise = global.Promise;

/*Get connection*/
var db = mongoose.connection;

/*Bind connection with error event*/
db.on('error', console.error.bind(console, 'MongoDB connection error:'));


module.exports = class catagories{
    
    /*Return all data of twitter news from (mlab)db*/
    getAllCatagories(){
        return new Promise((resolve , reject)=>{
            _catagories.find({} , (err , data)=>{
                if(err){
                    reject(`error : ${err}`);
                }else{
                    console.log('getAllCatagories:\n' + data);
                    resolve(data);
                }
            });
        });

    }

}
