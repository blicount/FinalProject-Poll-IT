var mongoose    = require('mongoose');

catagory = new mongoose.Schema({

    _catagoryId:{
        type:Number,
        index:1,
        required:true
    },
    _catagoryName:{
        type:String,
        required:true
    },
    _catagoryImg:{
        type:String,
        required:true
    },
     _catagoryNav : [String],
     place : [place]
    },{collection : 'catagories'})



/*export scema*/
var Catagory = mongoose.model('Catagory' , catagory);
module.exports = Catagory;